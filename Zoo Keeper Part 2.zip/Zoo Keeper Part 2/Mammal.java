public class Mammal {
    int energyLevel = 100;
    int displayEnergy() {
        System.out.printf("Energy Level: %s\n", energyLevel);
        return energyLevel;
    }
    
    public Mammal(int energyLevel) {
        this.energyLevel = energyLevel;
    }
}
