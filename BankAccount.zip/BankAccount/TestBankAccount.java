class TestBankAccount {
    public static void main(String[] args) {
		BankAccount nathanBankAccount = new BankAccount();
		nathanBankAccount.depositMoney(300, "checking");
		nathanBankAccount.depositMoney(40, "savings");
    	nathanBankAccount.withdrawMoney(50, "checking");
		nathanBankAccount.withdrawMoney(50, "savings");

		

        BankAccount spencerBankAccount2 = new BankAccount();
		spencerBankAccount2.depositMoney(10, "checking");
		spencerBankAccount2.depositMoney(200, "savings");
        spencerBankAccount2.withdrawMoney(60, "checking");

        // nathanBankAccount.displayAccountBalance();
        // spencerBankAccount2.displayAccountBalance();

        System.out.println(nathanBankAccount.getCheckingBalance());
        System.out.println(nathanBankAccount.getSavingsBalance());

        System.out.println(spencerBankAccount2.getCheckingBalance());
        System.out.println(spencerBankAccount2.getSavingsBalance());


        System.out.println(BankAccount.totalHoldings);
	}
}